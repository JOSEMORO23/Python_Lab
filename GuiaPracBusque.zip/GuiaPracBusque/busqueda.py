# Importación de librerías necesarias
import json            # Para leer y escribir archivos JSON
import argparse        # Para analizar argumentos desde línea de comandos
import sys             # Para salida del programa si ocurre un error
import heapq           # Para la cola de prioridad del algoritmo de Dijkstra
import networkx as nx  # Para representar y dibujar el grafo
import matplotlib.pyplot as plt  # Para mostrar gráficos

GRAPH_FILE = "ecuador_graph.json"   # Archivo donde se guarda el grafo persistente

# ------------------------------------------------------------------
# Cargar grafo desde JSON o usar valor por defecto
# ------------------------------------------------------------------
def load_graph():
     # Intenta abrir y leer el grafo desde archivo
    try:
        with open(GRAPH_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        # Si no existe el archivo, devuelve un grafo inicial con ciudades de Ecuador
        # Grafo inicial con distancias aproximadas en km
        return {
              # Cada ciudad contiene un diccionario con ciudades vecinas y la distancia en km
            "Tulcán": {"Ibarra": 120},
            "Ibarra": {"Tulcán": 120, "Quito": 115, "Esmeraldas": 170},
            "Esmeraldas": {"Ibarra": 170, "Santo Domingo": 190},
            "Quito": {"Ibarra": 115, "Latacunga": 90, "Santo Domingo": 140},
            "Latacunga": {"Quito": 90, "Ambato": 40},
            "Ambato": {"Latacunga": 40, "Riobamba": 55},
            "Riobamba": {"Ambato": 55, "Guaranda": 60, "Cuenca": 190},
            "Guaranda": {"Riobamba": 60, "Babahoyo": 120},
            "Santo Domingo": {"Quito": 140, "Esmeraldas": 190, "Portoviejo": 160},
            "Portoviejo": {"Santo Domingo": 160, "Guayaquil": 200},
            "Babahoyo": {"Guaranda": 120, "Guayaquil": 70},
            "Guayaquil": {"Babahoyo": 70, "Portoviejo": 200, "Santa Elena": 140, "Machala": 180},
            "Santa Elena": {"Guayaquil": 140},
            "Machala": {"Guayaquil": 180, "Loja": 210},
            "Cuenca": {"Riobamba": 190, "Azogues": 30, "Loja": 210, "Macas": 220},
            "Azogues": {"Cuenca": 30},
            "Loja": {"Cuenca": 210, "Machala": 210, "Zamora": 60},
            "Zamora": {"Loja": 60, "Macas": 130},
            "Macas": {"Cuenca": 220, "Puyo": 180, "Zamora": 130},
            "Puyo": {"Macas": 180, "Tena": 110, "Ambato": 100},
            "Tena": {"Puyo": 110, "Orellana": 160},
            "Orellana": {"Tena": 160, "Nueva Loja": 240},
            "Nueva Loja": {"Orellana": 240, "Francisco de Orellana": 60},
            "Francisco de Orellana": {"Nueva Loja": 60}
        }

# ------------------------------------------------------------------
# Guardar grafo en JSON
# ------------------------------------------------------------------
def save_graph(graph):
      # Escribe el grafo en formato legible con identación
    with open(GRAPH_FILE, "w", encoding="utf-8") as f:
        json.dump(graph, f, ensure_ascii=False, indent=2)

# ------------------------------------------------------------------
# Algoritmo Dijkstra (ruta más corta con pesos)
# ------------------------------------------------------------------
def dijkstra(graph, start, goal):
    queue = [(0, [start])]  # Cola de prioridad con costo 0 y ciudad inicial
    visited = set()           # Ciudades ya visitadas
    while queue:
        cost, path = heapq.heappop(queue)  # Extrae el camino con menor costo
        city = path[-1]                    # Última ciudad del camino actual
        if city == goal:
            return path, cost   # Ruta encontrada
        if city in visited:
            continue           # Ya fue visitada
        visited.add(city)
        # Explora vecinos
        for neighbor, distance in graph.get(city, {}).items():
            if neighbor not in visited:
                heapq.heappush(queue, (cost + distance, path + [neighbor]))
    return None, float("inf") # Si no hay ruta

# ------------------------------------------------------------------
# Visualización (con resaltado de ruta)
# ------------------------------------------------------------------
def draw_graph(graph, path=None):
    """Dibuja el grafo completo y resalta la ruta si se proporciona."""
    G = nx.Graph()
    for city, neighbors in graph.items():
        for neighbor, weight in neighbors.items():
            G.add_edge(city, neighbor, weight=weight)
     # Agrega todas las ciudades y conexiones como aristas con peso

    pos = nx.spring_layout(G, seed=42)
    edge_labels = nx.get_edge_attributes(G, "weight")

    # 4.1 Dibujo base (nodos y aristas en gris claro)
    nx.draw(
        G,
        pos,
        with_labels=True,
        node_color="skyblue",
        node_size=1500,
        font_size=8,
        edge_color="lightgray",
    )

    # 4.2 Resaltar la ruta encontrada, si existe
    if path and len(path) > 1:
        # Crear lista de aristas (pares) en la ruta
        path_edges = [
            (path[i], path[i + 1]) if G.has_edge(path[i], path[i + 1]) else (path[i + 1], path[i])
            for i in range(len(path) - 1)
        ]
        nx.draw_networkx_edges(
            G,
            pos,
            edgelist=path_edges,
            width=3,
            edge_color="red",
        )

    # 4.3 Etiquetas de pesos en todas las aristas
    nx.draw_networkx_edge_labels(G, pos, edge_labels=edge_labels, font_size=7)

    title = "Mapa de ciudades conectadas (Ecuador)"
    if path and len(path) > 1:
        title += "\nRuta resaltada en rojo"
    plt.title(title)
    plt.show()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--add", nargs=3, metavar=("CIUDAD1", "CIUDAD2", "DISTANCIA"), help="Agrega conexión entre ciudades")
    parser.add_argument("--from", dest="origen", help="Ciudad de origen (modo no interactivo)")
    parser.add_argument("--to", dest="destino", help="Ciudad destino (modo no interactivo)")
    args = parser.parse_args()

    graph = load_graph()

    # --------------------------------------------------------------
    # Agregar conexión si se solicitó
    # --------------------------------------------------------------
    if args.add:
        c1, c2, dist = args.add
        dist = int(dist)
        graph.setdefault(c1, {})[c2] = dist
        graph.setdefault(c2, {})[c1] = dist
        save_graph(graph)
        print(f"Agregada conexión: {c1} <-> {c2} ({dist} km)")
        # Mostrar grafo actualizado
        draw_graph(graph)
        return

    # --------------------------------------------------------------
    # Obtener origen / destino (CLI o input)
    # --------------------------------------------------------------
    o = args.origen
    d = args.destino

    if not o or not d:
        # Modo interactivo si falta alguno
        print("\nCiudades disponibles:")
        print(", ".join(sorted(graph)))
        try:
            o = input("\nCiudad origen: ").strip()
            d = input("Ciudad destino: ").strip()
        except EOFError:
            print("[Error] No hay entrada interactiva. Usa --from y --to.")
            sys.exit(1)

    # --------------------------------------------------------------
    #  Validar ciudades
    # --------------------------------------------------------------
    if o not in graph or d not in graph:
        print("[Error] Una o ambas ciudades no existen en la base de datos.")
        sys.exit(1)

    # --------------------------------------------------------------
    # Calcular ruta y mostrar resultados
    # --------------------------------------------------------------
    ruta, costo = dijkstra(graph, o, d)
    if ruta:
        print("\nRuta más corta:")
        print(" -> ".join(ruta))  # Lista las ciudades del recorrido
        print(f"Distancia total: {costo} km") # Muestra distancia acumulada
        draw_graph(graph, ruta)              # Dibuja grafo con ruta resaltada
    else:
        print("No existe una ruta entre esas ciudades.")
        draw_graph(graph)  # Muestra grafo sin resaltar
# Punto de entrada principal del script
if __name__ == "__main__":
    main()
