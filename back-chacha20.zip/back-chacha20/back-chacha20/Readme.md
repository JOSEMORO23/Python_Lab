
# Proyecto de Mensajería Segura

Este proyecto es un sistema de mensajería segura en el que se utiliza cifrado de mensajes, autenticación de usuarios con JWT y una base de datos MongoDB para almacenar usuarios y mensajes de manera persistente. A continuación, se describe el proceso de ejecución y prueba del proyecto.

## Requisitos

- **Node.js** (versión 14 o superior)
- **MongoDB** (local o en la nube, por ejemplo, MongoDB Atlas)
- **Postman** (opcional, para realizar pruebas)

## Instalación de Dependencias

### 1. Instalar Node.js y npm

Asegúrate de tener **Node.js** y **npm** instalados. Si no los tienes, puedes descargar e instalar desde el [sitio oficial de Node.js](https://nodejs.org/).

Verifica la instalación ejecutando los siguientes comandos:
```bash
node -v
npm -v
```

### 2. Clonar o Descargar el Proyecto

Si estás utilizando Git, puedes clonar el repositorio con:
```bash
git clone <repositorio_url>
cd secure-messaging
```

### 3. Instalar las Dependencias del Backend

En la raíz del proyecto, ejecuta el siguiente comando para instalar todas las dependencias necesarias para el backend:
```bash
npm install
```

### 4. Instalar MongoDB

Si no tienes MongoDB instalado, puedes seguir las instrucciones en el [sitio oficial de MongoDB](https://www.mongodb.com/try/download/community) o usar **MongoDB Atlas** para obtener una base de datos en la nube.

Verifica que MongoDB esté corriendo localmente:
```bash
mongod
```

## Ejecución del Proyecto

### 1. Iniciar el Backend

En la raíz del proyecto, ejecuta el siguiente comando para iniciar el servidor:
```bash
node server.js
```
El servidor debería correr en el puerto **3000**. Si todo está configurado correctamente, verás el siguiente mensaje en la consola:
```bash
Server running on port 3000
```

### 2. Probar el Backend

#### 2.1 Registro de Usuario
Realiza una solicitud `POST` a `http://localhost:3000/register` con el siguiente cuerpo JSON:

```json
{
  "username": "user1",
  "password": "password123",
  "publicKey": "your_public_key_here"
}
```

#### 2.2 Inicio de Sesión
Realiza una solicitud `POST` a `http://localhost:3000/login` con el siguiente cuerpo JSON:

```json
{
  "username": "user1",
  "password": "password123"
}
```

Si las credenciales son correctas, recibirás un token JWT:
```json
{
  "message": "Login successful",
  "token": "your_jwt_token_here"
}
```

#### 2.3 Enviar Mensaje
Realiza una solicitud `POST` a `http://localhost:3000/sendMessage` con el siguiente cuerpo JSON:

```json
{
  "sender": "user1",
  "receiver": "user2",
  "message": "Hello, secure world!"
}
```

Asegúrate de incluir el token JWT en el encabezado `Authorization`:
```
Authorization: Bearer your_jwt_token_here
```

#### 2.4 Obtener Mensajes
Realiza una solicitud `GET` a `http://localhost:3000/getMessages?username=user1` para obtener los mensajes recibidos y ver el contenido descifrado.

### 3. Ejecutar el Frontend

Abre el archivo `index.html` en tu navegador para interactuar con la aplicación de mensajería segura. Puedes abrirlo directamente desde el navegador o usar un servidor local si prefieres.

### 4. Realizar Pruebas de Seguridad

Realiza pruebas de penetración (pen-test) para asegurarte de que:
- Los mensajes estén cifrados correctamente.
- Las rutas protegidas (como la de enviar mensajes) solo sean accesibles por usuarios autenticados.
- Las credenciales de usuario y los datos sensibles estén adecuadamente protegidos.

## Contribución

1. Haz un fork de este repositorio.
2. Crea una rama (`git checkout -b feature-nombre-de-tu-rama`).
3. Realiza tus cambios y haz commit (`git commit -m 'Añadir nueva funcionalidad'`).
4. Empuja tus cambios a tu repositorio remoto (`git push origin feature-nombre-de-tu-rama`).
5. Crea un pull request.

## Licencia

Este proyecto está bajo la Licencia MIT - consulta el archivo [LICENSE](LICENSE) para más detalles.
