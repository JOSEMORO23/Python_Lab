const { Message } = require('../models/Message');
const User = require('../models/User');
const { ChaCha20Poly1305 } = require('@stablelib/chacha20poly1305'); // Asegúrate de tener esta lib instalada
const { randomBytes } = require('crypto');

// Convertimos texto plano a Buffer
function encryptMessage(plainText, key) {
  const nonce = randomBytes(12); // 96 bits (recomendado)
  const chacha = new ChaCha20Poly1305(key);
  const ciphertext = chacha.seal(nonce, Buffer.from(plainText));
  return {
    nonce: nonce.toString('hex'),
    encrypted: Buffer.from(ciphertext).toString('hex')
  };
}

// Para descifrar
function decryptMessage(encryptedMessageHex, nonceHex, key) {
  const chacha = new ChaCha20Poly1305(key);
  const decrypted = chacha.open(
    Buffer.from(nonceHex, 'hex'),
    Buffer.from(encryptedMessageHex, 'hex')
  );
  return decrypted ? Buffer.from(decrypted).toString() : null;
}

exports.sendMessage = async (req, res) => {
  try {
    const { sender, receiver, message } = req.body;

    const receiverUser = await User.findOne({ username: receiver });
    if (!receiverUser) {
      return res.status(404).json({ message: 'Usuario receptor no encontrado' });
    }

    // Por ahora, clave estática (luego la puedes hacer por usuario)
    const key = Buffer.from('12345678901234567890123456789012'); // 32 bytes
    const { encrypted, nonce } = encryptMessage(message, key);

    const newMessage = new Message({
      sender,
      receiver,
      content: encrypted,
      nonce // se guarda también el nonce
    });

    await newMessage.save();

    res.status(200).json({ message: 'Mensaje enviado exitosamente', newMessage });
  } catch (error) {
    console.error('Error al enviar mensaje:', error);
    res.status(500).json({ error: 'Error interno del servidor' });
  }
};

exports.getMessages = async (req, res) => {
  try {
    const { username } = req.query;

    const userMessages = await Message.find({ receiver: username });

    const key = Buffer.from('12345678901234567890123456789012'); // 32 bytes

    const decryptedMessages = userMessages.map(msg => ({
      ...msg.toObject(),
      content: decryptMessage(msg.content, msg.nonce, key)
    }));

    res.status(200).json(decryptedMessages);
  } catch (error) {
    console.error('Error al obtener mensajes:', error);
    res.status(500).json({ error: 'Error interno del servidor' });
  }
};
